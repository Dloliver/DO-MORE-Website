// Do More ATL payment configuration.
//
// Stripe currently shows this Payment Link as Paused while the account is
// being verified. Keep the active flag false until Stripe marks the link Active.
export const STRATEGY_PAYMENT_URL =
  'https://buy.stripe.com/5kQ6oJ9gMaPGboideWbo400'

export const STRATEGY_PAYMENTS_ACTIVE = false
